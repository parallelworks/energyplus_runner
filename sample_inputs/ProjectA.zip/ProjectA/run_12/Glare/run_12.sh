#!/bin/bash

mono /opt/diva/bin/diva.exe glare run_12.dlt