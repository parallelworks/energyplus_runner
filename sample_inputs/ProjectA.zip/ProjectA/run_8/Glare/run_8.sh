#!/bin/bash

mono /opt/diva/bin/diva.exe glare run_8.dlt