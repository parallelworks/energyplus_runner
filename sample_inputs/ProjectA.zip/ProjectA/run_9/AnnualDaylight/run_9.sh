#!/bin/bash
#C:\DIVA\WeatherData\USA_MA_Boston-Logan.Intl.AP.725090_TMY3.epw

mono /opt/diva/bin/diva.exe annualdaylight run_9.dlt USA_MA_Boston-Logan.Intl.AP.725090_TMY3.epw